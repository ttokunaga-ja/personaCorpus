pub fn gate_state(approved: bool) -> &'static str { if approved { "approved" } else { "awaiting_approval" } }
