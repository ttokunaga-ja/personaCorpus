export function mapRelease(state: "awaiting_approval" | "approved"){return {state,approvalGate:"ADR-042" as const};}
