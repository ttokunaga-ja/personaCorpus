# Vendor SDK snapshot - synthetic evaluation

This archive supports Aster Loop株式会社 evaluation of Product Alpha R7 for release 2026-07-13. All packages and tier names are invented. The adapter pattern retains ADR-042 approval ownership in the application and targets p95 184 ms for control-plane calls.
